package using;

public class CyminimiDTO {
	String userid, saveFileName, originalFileName, imgx,imgy;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getSaveFileName() {
		return saveFileName;
	}

	public void setSaveFileName(String saveFileName) {
		this.saveFileName = saveFileName;
	}

	public String getOriginalFileName() {
		return originalFileName;
	}

	public void setOriginalFileName(String originalFileName) {
		this.originalFileName = originalFileName;
	}

	public String getImgx() {
		return imgx;
	}

	public void setImgx(String imgx) {
		this.imgx = imgx;
	}

	public String getImgy() {
		return imgy;
	}

	public void setImgy(String imgy) {
		this.imgy = imgy;
	}
}
