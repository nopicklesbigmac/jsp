package member;

public class CyMemberListDTO {
	private String userId1, userValue1,userName1, userId2, userName2, userValue2, userMessege;
	private int type;
	
	public String getUserId1() {
		return userId1;
	}

	public void setUserId1(String userId1) {
		this.userId1 = userId1;
	}

	public String getUserValue1() {
		return userValue1;
	}

	public void setUserValue1(String userValue1) {
		this.userValue1 = userValue1;
	}

	public String getUserName1() {
		return userName1;
	}

	public void setUserName1(String userName1) {
		this.userName1 = userName1;
	}

	public String getUserId2() {
		return userId2;
	}

	public void setUserId2(String userId2) {
		this.userId2 = userId2;
	}

	public String getUserName2() {
		return userName2;
	}

	public void setUserName2(String userName2) {
		this.userName2 = userName2;
	}

	public String getUserValue2() {
		return userValue2;
	}

	public void setUserValue2(String userValue2) {
		this.userValue2 = userValue2;
	}

	public String getUserMessege() {
		return userMessege;
	}

	public void setUserMessege(String userMessege) {
		this.userMessege = userMessege;
	}
	
	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

}
